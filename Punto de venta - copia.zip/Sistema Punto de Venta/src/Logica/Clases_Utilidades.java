package Logica;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.draw.LineSeparator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

public class Clases_Utilidades {

    public static ArrayList<Categoria> Lista_Categorias = new ArrayList<>();
    public static ArrayList<Producto> Lista_Productos = new ArrayList<>();
    public static ArrayList<Cajero> Lista_Cajeros = new ArrayList<>();
    public static ArrayList<Venta> Lista_Ventas = new ArrayList<>();
    public static int Contador_Ventas = 0;

    public static class Categoria {

        private int ID_Categoria;
        private String Nombre;
        private boolean Estado;

        public Categoria(int ID_Categoria, String Nombre) {
            this.ID_Categoria = ID_Categoria;
            this.Nombre = Nombre;
            this.Estado = true;
        }

        public void setID_Categoria(int ID_Categoria) {
            this.ID_Categoria = ID_Categoria;
        }

        public int getID_Categoria() {
            return ID_Categoria;
        }

        public void setNombre(String Nombre) {
            this.Nombre = Nombre;
        }

        public String getNombre() {
            return Nombre;
        }

        public void setEstado(boolean Estado) {
            this.Estado = Estado;
        }

        public boolean getEstado() {
            return Estado;
        }

        @Override
        public String toString() {
            return this.getNombre();
        }

        public static Categoria Buscar_Categoria(int ID_Categoria) {
            for (Categoria Categoria : Lista_Categorias) {
                if (Categoria.getID_Categoria() == ID_Categoria) {
                    return Categoria;
                }
            }
            return null;
        }
    }

    public static class Producto {

        private int ID_Producto;
        private String Nombre;
        private double Precio;
        private int Cantidad = 0;
        private Categoria Categoria;
        private boolean Estado;

        public Producto(int ID, String Nombre, double Precio, int Cantidad, Categoria Categoria) {
            this.ID_Producto = ID;
            this.Nombre = Nombre;
            this.Precio = Precio;
            this.Cantidad = Cantidad;
            this.Categoria = Categoria;
            this.Estado = true;
        }

        public int getID_Producto() {
            return ID_Producto;
        }

        public void setNombre(String Nombre) {
            this.Nombre = Nombre;
        }

        public String getNombre() {
            return Nombre;
        }

        public void setPrecio(double Precio) {
            this.Precio = Precio;
        }

        public double getPrecio() {
            return Precio;
        }

        public void setCantidad(int Cantidad) {
            this.Cantidad = Cantidad;
        }

        public int getCantidad() {
            return Cantidad;
        }

        public void setCategoria(Categoria Categoria) {
            this.Categoria = Categoria;
        }

        public Categoria getCategoria() {
            return Categoria;
        }

        public void setEstado(boolean Estado) {
            this.Estado = Estado;
        }

        public boolean getEstado() {
            return Estado;
        }

        public static Producto Buscar_Producto(int ID_Producto) {
            for (Producto Producto : Lista_Productos) {
                if (Producto.getID_Producto() == ID_Producto) {
                    return Producto;
                }
            }
            return null;
        }

        public static boolean Eliminar_Producto(int ID_Producto) {
            for (Producto Producto : Lista_Productos) {
                if (Producto.getID_Producto() == ID_Producto) {
                    Lista_Productos.remove(Producto);
                    return true;
                }
            }
            return false;
        }

    }

    public static class Cajero {

        private int ID_Cajero;
        private String Nombres;
        private String Apellidos;
        private boolean Estado;

        public Cajero(int ID_Cajero, String Nombre, String Apellido) {
            this.ID_Cajero = ID_Cajero;
            this.Nombres = Nombre;
            this.Apellidos = Apellido;
            this.Estado = true;
        }

        public void setID_Cajero(int ID_Cajero) {
            this.ID_Cajero = ID_Cajero;
        }

        public int getID_Cajero() {
            return ID_Cajero;
        }

        public void setNombres(String Nombre) {
            this.Nombres = Nombre;
        }

        public String getNombres() {
            return Nombres;
        }

        public void setApellidos(String Apellido) {
            this.Apellidos = Apellido;
        }

        public String getApellidos() {
            return Apellidos;
        }

        public void setEstado(boolean Estado) {
            this.Estado = Estado;
        }

        public boolean getEstado() {
            return Estado;
        }

        @Override
        public String toString() {
            return this.getNombres();
        }

        public static Cajero Buscar_Cajero(int ID_Cajero) {
            for (Cajero Cajero : Lista_Cajeros) {
                if (Cajero.getID_Cajero() == ID_Cajero) {
                    return Cajero;
                }
            }
            return null;
        }
    }

    public static class Venta {

        private int ID_Venta;
        public ArrayList<Producto> Productos_Vendidos;
        public double Total_Dinero;
        private Cajero Cajero_Asignado;
        private Date Fecha_Venta;

        public Venta(Cajero Cajero) {
            this.ID_Venta = Contador_Ventas++;
            this.Productos_Vendidos = new ArrayList<>();
            this.Total_Dinero = 0.0;
            this.Cajero_Asignado = Cajero;
            this.Fecha_Venta = new Date();
        }
    }

    public static class Limitador_Caracteres_Y_Tipo extends DocumentFilter {

        public enum Modo {
            LETRAS,
            NUMEROS_ENTEROS,
            NUMEROS_DECIMALES,
            AMBOS
        }

        private final int Maximo_Caracteres;
        private final Modo Modo;

        public Limitador_Caracteres_Y_Tipo(int Maximo_Caracteres, Modo Modo) {
            this.Maximo_Caracteres = Maximo_Caracteres;
            this.Modo = Modo;
        }

        @Override
        public void insertString(FilterBypass Fb, int offset, String Texto, AttributeSet Atributo)
                throws BadLocationException {

            if (Texto == null) {
                return;
            }

            if (!Validar_Texto(Fb, Texto)) {
                return;
            }

            if ((Fb.getDocument().getLength() + Texto.length()) <= Maximo_Caracteres) {
                super.insertString(Fb, offset, Texto, Atributo);
            }
        }

        @Override
        public void replace(FilterBypass Fb, int Offset, int Longitud, String Texto, AttributeSet Atributo)
                throws BadLocationException {

            if (Texto == null) {
                super.replace(Fb, Offset, Longitud, Texto, Atributo);
                return;
            }

            if (Texto.isEmpty()) {
                super.replace(Fb, Offset, Longitud, Texto, Atributo);
                return;
            }

            if (!Validar_Texto(Fb, Texto)) {
                return;
            }

            int nuevaLongitud = Fb.getDocument().getLength() - Longitud + Texto.length();
            if (nuevaLongitud <= Maximo_Caracteres) {
                super.replace(Fb, Offset, Longitud, Texto, Atributo);
            }
        }

        private boolean Validar_Texto(FilterBypass Fb, String Texto) throws BadLocationException {
            String Texto_Actual = Fb.getDocument().getText(0, Fb.getDocument().getLength());

            switch (Modo) {

                case LETRAS:
                    return Texto.matches("[\\p{L} ]+");

                case NUMEROS_ENTEROS:
                    return Texto.matches("\\d+");

                case NUMEROS_DECIMALES:
                    if (!Texto.matches("[0-9.]+")) {
                        return false;
                    }
                    if (Texto.contains(".") && Texto_Actual.contains(".")) {
                        return false;
                    }
                    return true;

                case AMBOS:
                    return Texto.matches("[\\p{L}\\d ]+");

                default:
                    return true;
            }
        }

    }

    public static void Actualizar_Productos_ComboBox_Categorias(JComboBox ComboBox_Categorias) {
        ComboBox_Categorias.removeAllItems();
        ComboBox_Categorias.addItem(new Categoria(0, "Seleccione la categoria"));

        for (Categoria Categoria : Lista_Categorias) {
            if (Categoria.getEstado()) {
                ComboBox_Categorias.addItem(Categoria);
            }
        }

        ComboBox_Categorias.setSelectedIndex(0);
    }

    public static void Actualizar_Productos_Tabla(JTable Tabla_Productos) {
        DefaultTableModel Modelo = (DefaultTableModel) Tabla_Productos.getModel();
        Modelo.setRowCount(0);

        for (Producto Producto : Lista_Productos) {
            Modelo.addRow(new Object[]{
                Producto.getID_Producto(),
                Producto.getNombre(),
                Producto.getPrecio(),
                Producto.getCantidad(),
                Producto.getCategoria(),
                Producto.getEstado()
            });
        }
    }

    public static void Actualizar_Categorias_Tabla(JTable Tabla_Categorias) {
        DefaultTableModel Modelo = (DefaultTableModel) Tabla_Categorias.getModel();
        Modelo.setRowCount(0);

        for (Categoria Categoria : Lista_Categorias) {
            Modelo.addRow(new Object[]{
                Categoria.getID_Categoria(),
                Categoria.getNombre(),
                Categoria.getEstado()
            });
        }
    }

    public static void Actualizar_Cajeros_Tabla(JTable Tabla_Cajeros) {
        DefaultTableModel Modelo = (DefaultTableModel) Tabla_Cajeros.getModel();
        Modelo.setRowCount(0);

        for (Cajero Cajero : Lista_Cajeros) {
            Modelo.addRow(new Object[]{
                Cajero.getID_Cajero(),
                Cajero.getNombres(),
                Cajero.getApellidos(),
                Cajero.getEstado()
            });
        }
    }

    public static void Reloj_Ventas(JLabel Label_Reloj) {
        Timer Timer = new Timer(1000, e -> {
            String Formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
            Label_Reloj.setText(Formato);
        });
        Timer.start();

        Label_Reloj.setText(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()));
    }

    public static void Actualizar_Vender_ComboBox_Cajeros(JComboBox ComboBox_Cajeros) {
        ComboBox_Cajeros.removeAllItems();
        ComboBox_Cajeros.addItem(new Categoria(0, "Seleccione al cajero"));

        for (Cajero Cajero : Lista_Cajeros) {
            if (Cajero.getEstado()) {
                ComboBox_Cajeros.addItem(Cajero);
            }
        }
        ComboBox_Cajeros.setSelectedIndex(0);
    }

    public static void Actualizar_Vender_Total_Carrito(DefaultTableModel Modelo, JTextField TxFd_Total_Carrito) {
        double Total = 0;
        for (int i = 0; i < Modelo.getRowCount(); i++) {
            Total += (double) Modelo.getValueAt(i, 5);
        }
        TxFd_Total_Carrito.setText(String.valueOf(Total));
    }

    public static void PDF_RegistroVentas(Document Documento_PDF, ArrayList<Clases_Utilidades.Venta> Ventas) throws DocumentException {
        Documento_PDF.add(new Paragraph("REGISTRO DE VENTAS"));
        LineSeparator Separador = new LineSeparator();
        Separador.setOffset(-2);
        Separador.setLineColor(BaseColor.BLACK);
        Documento_PDF.add(new Chunk(Separador));

        Font Fuente = new Font(Font.FontFamily.HELVETICA, 8, Font.BOLD);

        PdfPTable Tabla = new PdfPTable(8);
        Tabla.setWidthPercentage(100);

        String[] Titulos = {"N°", "ID Venta", "Cajero", "Fecha", "Producto", "Cantidad", "Precio Unit", "Total Producto"};
        for (String Titulo : Titulos) {
            PdfPCell Celda = new PdfPCell(new Phrase(Titulo, Fuente));
            Celda.setBackgroundColor(BaseColor.LIGHT_GRAY);
            Celda.setHorizontalAlignment(Element.ALIGN_CENTER);
            Celda.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Tabla.addCell(Celda);
        }

        int Contador = 1;

        for (Clases_Utilidades.Venta Venta : Ventas) {
            for (Clases_Utilidades.Producto productoVendido : Venta.Productos_Vendidos) {

                PdfPCell Numero_Celda = new PdfPCell(new Phrase(String.valueOf(Contador), Fuente));
                Numero_Celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                Tabla.addCell(Numero_Celda);

                PdfPCell Celda_Venta = new PdfPCell(new Phrase(String.valueOf(Venta.ID_Venta), Fuente));
                Celda_Venta.setHorizontalAlignment(Element.ALIGN_CENTER);
                Tabla.addCell(Celda_Venta);

                PdfPCell Celda_Cajero = new PdfPCell(new Phrase(Venta.Cajero_Asignado.getNombres(), Fuente));
                Celda_Cajero.setHorizontalAlignment(Element.ALIGN_CENTER);
                Tabla.addCell(Celda_Cajero);

                PdfPCell Celda_Fecha = new PdfPCell(new Phrase(Venta.Fecha_Venta.toString(), Fuente));
                Celda_Fecha.setHorizontalAlignment(Element.ALIGN_CENTER);
                Tabla.addCell(Celda_Fecha);

                PdfPCell Celda_Producto = new PdfPCell(new Phrase(productoVendido.getNombre(), Fuente));
                Celda_Producto.setHorizontalAlignment(Element.ALIGN_CENTER);
                Tabla.addCell(Celda_Producto);

                PdfPCell Celda_Cantidad = new PdfPCell(new Phrase(String.valueOf(productoVendido.getCantidad()), Fuente));
                Celda_Cantidad.setHorizontalAlignment(Element.ALIGN_CENTER);
                Tabla.addCell(Celda_Cantidad);

                PdfPCell Celda_Precio_Unitario = new PdfPCell(new Phrase(String.valueOf(productoVendido.getPrecio()), Fuente));
                Celda_Precio_Unitario.setHorizontalAlignment(Element.ALIGN_CENTER);
                Tabla.addCell(Celda_Precio_Unitario);

                PdfPCell Celda_Total = new PdfPCell(new Phrase(String.valueOf(productoVendido.getCantidad() * productoVendido.getPrecio()), Fuente));
                Celda_Total.setHorizontalAlignment(Element.ALIGN_CENTER);
                Tabla.addCell(Celda_Total);

                Contador++;
            }
        }

        Documento_PDF.add(new Chunk());
        Documento_PDF.add(Tabla);
    }

}
