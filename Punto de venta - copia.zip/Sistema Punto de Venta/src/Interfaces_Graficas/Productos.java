/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfaces_Graficas;

import static Logica.Clases_Utilidades.Actualizar_Productos_ComboBox_Categorias;
import static Logica.Clases_Utilidades.Actualizar_Productos_Tabla;
import Logica.Clases_Utilidades.Categoria;
import Logica.Clases_Utilidades.Limitador_Caracteres_Y_Tipo;
import static Logica.Clases_Utilidades.Lista_Categorias;
import static Logica.Clases_Utilidades.Lista_Productos;
import Logica.Clases_Utilidades.Producto;
import static Logica.Clases_Utilidades.Producto.Buscar_Producto;
import static Logica.Clases_Utilidades.Producto.Eliminar_Producto;
import java.awt.HeadlessException;
import javax.swing.JOptionPane;
import javax.swing.text.AbstractDocument;

public class Productos extends javax.swing.JFrame {

    private Menu_Principal Menu_Principal;

    public void setMenu_Principal(Menu_Principal Menu_Principal) {
        this.Menu_Principal = Menu_Principal;
    }

    public Productos() {
        initComponents();
        this.setLocationRelativeTo(null);
        Actualizar_Productos_Tabla(Tabla);
        Actualizar_Productos_ComboBox_Categorias(ComboBox_Categorias);
        ((AbstractDocument) TxFd_ID_Producto.getDocument()).setDocumentFilter(new Limitador_Caracteres_Y_Tipo(5, Limitador_Caracteres_Y_Tipo.Modo.NUMEROS_ENTEROS));
        ((AbstractDocument) TxFd_Nombre.getDocument()).setDocumentFilter(new Limitador_Caracteres_Y_Tipo(30, Limitador_Caracteres_Y_Tipo.Modo.LETRAS));
        ((AbstractDocument) TxFd_Precio.getDocument()).setDocumentFilter(new Limitador_Caracteres_Y_Tipo(10, Limitador_Caracteres_Y_Tipo.Modo.NUMEROS_DECIMALES));
        ((AbstractDocument) TxFd_Cantidad.getDocument()).setDocumentFilter(new Limitador_Caracteres_Y_Tipo(10, Limitador_Caracteres_Y_Tipo.Modo.NUMEROS_ENTEROS));
        Btn_Actualizar.setVisible(false);
        Btn_Eliminar.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        JPanel2 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        TxFd_ID_Producto = new javax.swing.JTextField();
        TxFd_Nombre = new javax.swing.JTextField();
        TxFd_Precio = new javax.swing.JTextField();
        TxFd_Cantidad = new javax.swing.JTextField();
        Btn_Agregar = new javax.swing.JButton();
        Btn_Actualizar = new javax.swing.JButton();
        Btn_Eliminar = new javax.swing.JButton();
        ComboBox_Categorias = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        ComboBox_Estado = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Productos");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(2, 104, 115));
        jPanel3.setMaximumSize(new java.awt.Dimension(100, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(100, 500));
        jPanel3.setName(""); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 750));

        JPanel2.setBackground(new java.awt.Color(4, 191, 138));

        javax.swing.GroupLayout JPanel2Layout = new javax.swing.GroupLayout(JPanel2);
        JPanel2.setLayout(JPanel2Layout);
        JPanel2Layout.setHorizontalGroup(
            JPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );
        JPanel2Layout.setVerticalGroup(
            JPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        getContentPane().add(JPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 750, 100));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Nombre:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("ID Producto:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Precio:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Cantidad:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Categoria:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        TxFd_ID_Producto.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_ID_Producto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_ID_Producto.setForeground(new java.awt.Color(0, 0, 0));
        TxFd_ID_Producto.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                TxFd_ID_ProductoFocusGained(evt);
            }
        });
        TxFd_ID_Producto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TxFd_ID_ProductoKeyReleased(evt);
            }
        });
        jPanel2.add(TxFd_ID_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 110, 30));

        TxFd_Nombre.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Nombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Nombre.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(TxFd_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, 230, 30));

        TxFd_Precio.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Precio.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Precio.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(TxFd_Precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 100, 30));

        TxFd_Cantidad.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Cantidad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Cantidad.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(TxFd_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 170, 100, 30));

        Btn_Agregar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Agregar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Agregar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Agregar.setText("Agregar");
        Btn_Agregar.setToolTipText("Agrega un nuevo producto.");
        Btn_Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_AgregarActionPerformed(evt);
            }
        });
        jPanel2.add(Btn_Agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 100, 200, 50));

        Btn_Actualizar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Actualizar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Actualizar.setText("Actualizar");
        Btn_Actualizar.setToolTipText("Se puede editar el nombre, precio, cantidad, categoria y estado.");
        Btn_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ActualizarActionPerformed(evt);
            }
        });
        jPanel2.add(Btn_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 160, 200, 50));

        Btn_Eliminar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Eliminar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Eliminar.setText("Eliminar");
        Btn_Eliminar.setToolTipText("Ingresa el ID para eliminar el producto");
        Btn_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_EliminarActionPerformed(evt);
            }
        });
        jPanel2.add(Btn_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 220, 200, 50));

        ComboBox_Categorias.setBackground(new java.awt.Color(255, 255, 255));
        ComboBox_Categorias.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ComboBox_Categorias.setForeground(new java.awt.Color(0, 0, 0));
        jPanel2.add(ComboBox_Categorias, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 230, 30));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Estado:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));

        Tabla.setBackground(new java.awt.Color(255, 255, 255));
        Tabla.setForeground(new java.awt.Color(0, 0, 0));
        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Precio", "Cantidad", "Categoria", "Estado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Double.class, java.lang.Integer.class, java.lang.Object.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Tabla.setDoubleBuffered(true);
        jScrollPane1.setViewportView(Tabla);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 730, 330));

        ComboBox_Estado.setBackground(new java.awt.Color(255, 255, 255));
        ComboBox_Estado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ComboBox_Estado.setForeground(new java.awt.Color(0, 0, 0));
        ComboBox_Estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));
        jPanel2.add(ComboBox_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 272, 100, 30));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 750, 650));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AgregarActionPerformed
        try {
            if (TxFd_ID_Producto.getText().isBlank() || TxFd_Nombre.getText().isBlank() || TxFd_Precio.getText().isBlank() || TxFd_Cantidad.getText().isBlank()) {
                JOptionPane.showMessageDialog(this, "Llene todos los campos de texto.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (Lista_Categorias.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay ninguna categoria registrada, agrege una en el apartado de categorias.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (ComboBox_Categorias.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Seleccione a que categoria pertenece.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int ID_Producto = Integer.parseInt(TxFd_ID_Producto.getText());
            String Nombre = TxFd_Nombre.getText();
            double Precio = Double.parseDouble(TxFd_Precio.getText());
            int Cantidad = Integer.parseInt(TxFd_Cantidad.getText());
            Categoria Categoria = (Categoria) ComboBox_Categorias.getSelectedItem();

            Producto Producto = new Producto(ID_Producto, Nombre, Precio, Cantidad, Categoria);
            Lista_Productos.add(Producto);
            Btn_Agregar.setVisible(false);
            Btn_Actualizar.setVisible(true);
            Actualizar_Productos_Tabla(Tabla);

            JOptionPane.showMessageDialog(this, "Se agrego correctamente el producto.");
        } catch (HeadlessException | NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error en agregar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_AgregarActionPerformed

    private void Btn_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ActualizarActionPerformed
        try {
            int ID_Producto = Integer.parseInt(TxFd_ID_Producto.getText());
            Producto Producto = Buscar_Producto(ID_Producto);

            Producto.setNombre(TxFd_Nombre.getText());
            Producto.setPrecio(Double.parseDouble(TxFd_Precio.getText()));
            Producto.setCantidad(Integer.parseInt(TxFd_Cantidad.getText()));
            Producto.setCategoria((Categoria) ComboBox_Categorias.getSelectedItem());
            if (ComboBox_Estado.getSelectedIndex() == 0) {
                Producto.setEstado(true);
            } else {
                Producto.setEstado(false);
            }
            Actualizar_Productos_Tabla(Tabla);

            JOptionPane.showMessageDialog(this, "Producto editado correctamente");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en editar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_ActualizarActionPerformed

    private void TxFd_ID_ProductoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxFd_ID_ProductoKeyReleased
        if (TxFd_ID_Producto.getText().isBlank()) {
            return;
        }
        try {
            int ID_Producto = Integer.parseInt(TxFd_ID_Producto.getText());
            Producto Producto = Buscar_Producto(ID_Producto);

            if (Producto != null) {
                TxFd_Nombre.setText(Producto.getNombre());
                TxFd_Precio.setText(String.valueOf(Producto.getPrecio()));
                TxFd_Cantidad.setText(String.valueOf(Producto.getCantidad()));
                if (Producto.getEstado()) {
                    ComboBox_Estado.setSelectedIndex(0);
                } else {
                    ComboBox_Estado.setSelectedIndex(1);
                }
                Btn_Actualizar.setVisible(true);
                Btn_Eliminar.setVisible(true);

                for (Categoria Categoria : Lista_Categorias) {
                    if (Categoria.getID_Categoria() == Producto.getCategoria().getID_Categoria()) {
                        ComboBox_Categorias.setSelectedItem(Categoria);
                        break;
                    }
                }

            } else {
                TxFd_Nombre.setText("");
                TxFd_Precio.setText("");
                TxFd_Cantidad.setText("");
                ComboBox_Categorias.setSelectedIndex(0);
                Btn_Actualizar.setVisible(false);
                Btn_Eliminar.setVisible(false);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en keylistener.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_TxFd_ID_ProductoKeyReleased

    private void TxFd_ID_ProductoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TxFd_ID_ProductoFocusGained
        TxFd_ID_Producto.selectAll();
    }//GEN-LAST:event_TxFd_ID_ProductoFocusGained

    private void Btn_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EliminarActionPerformed
        try {
            int ID_Producto = Integer.parseInt(TxFd_ID_Producto.getText());
            boolean Eliminado = false;

            int Confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar este producto? ", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
            if (Confirmacion == JOptionPane.YES_OPTION) {
                Eliminado = Eliminar_Producto(ID_Producto);
            } else {
                JOptionPane.showMessageDialog(this, "Operacion cancelada", "Error", JOptionPane.ERROR_MESSAGE);
            }

            Actualizar_Productos_Tabla(Tabla);

            if (Eliminado) {
                JOptionPane.showMessageDialog(this, "Producto eliminado correctamente");

                TxFd_ID_Producto.setText("");
                TxFd_Nombre.setText("");
                TxFd_Precio.setText("");
                TxFd_Cantidad.setText("");
                ComboBox_Categorias.setSelectedIndex(0);
            } else {
                JOptionPane.showMessageDialog(this, "No existe un producto con ese ID", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error en eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_Btn_EliminarActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        Menu_Principal.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_Actualizar;
    private javax.swing.JButton Btn_Agregar;
    private javax.swing.JButton Btn_Eliminar;
    private javax.swing.JComboBox<Categoria> ComboBox_Categorias;
    private javax.swing.JComboBox<String> ComboBox_Estado;
    private javax.swing.JPanel JPanel2;
    private javax.swing.JTable Tabla;
    private javax.swing.JTextField TxFd_Cantidad;
    private javax.swing.JTextField TxFd_ID_Producto;
    private javax.swing.JTextField TxFd_Nombre;
    private javax.swing.JTextField TxFd_Precio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
