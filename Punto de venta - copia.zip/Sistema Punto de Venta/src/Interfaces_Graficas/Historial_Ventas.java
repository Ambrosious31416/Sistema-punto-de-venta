/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfaces_Graficas;

import Logica.Clases_Utilidades;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;

public class Historial_Ventas extends javax.swing.JFrame {

    private Menu_Principal Menu_Principal;

    public void setMenu_Principal(Menu_Principal Menu_Principal) {
        this.Menu_Principal = Menu_Principal;
    }

    public Historial_Ventas() {
        initComponents();
        Tabla_Historial_Ventas.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        JPanel2 = new javax.swing.JPanel();
        Label_Reloj = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla_Historial_Ventas = new javax.swing.JTable();
        Btn_Registro = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(2, 104, 115));
        jPanel3.setMaximumSize(new java.awt.Dimension(100, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(100, 500));
        jPanel3.setName(""); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 750));

        JPanel2.setBackground(new java.awt.Color(4, 191, 138));
        JPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Label_Reloj.setBackground(new java.awt.Color(255, 255, 255));
        Label_Reloj.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        JPanel2.add(Label_Reloj, new org.netbeans.lib.awtextra.AbsoluteConstraints(415, 33, 310, 40));

        getContentPane().add(JPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 750, 100));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Tabla_Historial_Ventas.setBackground(new java.awt.Color(255, 255, 255));
        Tabla_Historial_Ventas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Tabla_Historial_Ventas.setForeground(new java.awt.Color(0, 0, 0));
        Tabla_Historial_Ventas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "N°", "ID", "Cajero", "Fecha", "Producto", "Cantidad", "Precio Unit", "Total Producto"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla_Historial_Ventas);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 730, 460));

        Btn_Registro.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Registro.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Registro.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Registro.setText("Registro");
        Btn_Registro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_RegistroActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Registro, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, 200, 60));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 750, 650));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_RegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RegistroActionPerformed
        try {
            if (Clases_Utilidades.Lista_Ventas.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay ventas registradas.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String Ruta_Descargas = System.getProperty("user.home") + "/Downloads/Registro_Ventas.pdf";

            Document Documento = new Document();
            PdfWriter.getInstance(Documento, new FileOutputStream(Ruta_Descargas));
            Documento.open();

            Clases_Utilidades.PDF_RegistroVentas(Documento, Clases_Utilidades.Lista_Ventas);

            Documento.close();
            JOptionPane.showMessageDialog(this, "PDF generado correctamente en: " + Ruta_Descargas);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al generar PDF: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_RegistroActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_Registro;
    private javax.swing.JPanel JPanel2;
    private javax.swing.JLabel Label_Reloj;
    private javax.swing.JTable Tabla_Historial_Ventas;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
