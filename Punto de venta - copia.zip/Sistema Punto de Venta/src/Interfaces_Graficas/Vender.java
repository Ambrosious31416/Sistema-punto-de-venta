/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfaces_Graficas;

import Logica.Clases_Utilidades;
import static Logica.Clases_Utilidades.Actualizar_Vender_ComboBox_Cajeros;
import static Logica.Clases_Utilidades.Actualizar_Vender_Total_Carrito;
import Logica.Clases_Utilidades.Cajero;
import Logica.Clases_Utilidades.Producto;
import static Logica.Clases_Utilidades.Producto.Buscar_Producto;
import static Logica.Clases_Utilidades.Reloj_Ventas;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;

public class Vender extends javax.swing.JFrame {

    private Menu_Principal Menu_Principal;

    public void setMenu_Principal(Menu_Principal Menu_Principal) {
        this.Menu_Principal = Menu_Principal;
    }

    private final DefaultTableModel Modelo;

    public Vender() {
        initComponents();
        this.setLocationRelativeTo(null);
        Modelo = (DefaultTableModel) Tabla_Vender.getModel();
        Reloj_Ventas(Label_Reloj);
        Actualizar_Vender_ComboBox_Cajeros(ComboBox_Cajero);
        ((AbstractDocument) TxFd_ID_Producto.getDocument()).setDocumentFilter(new Clases_Utilidades.Limitador_Caracteres_Y_Tipo(5, Clases_Utilidades.Limitador_Caracteres_Y_Tipo.Modo.NUMEROS_ENTEROS));
        ((AbstractDocument) TxFd_Cantidad_Tomar.getDocument()).setDocumentFilter(new Clases_Utilidades.Limitador_Caracteres_Y_Tipo(38, Clases_Utilidades.Limitador_Caracteres_Y_Tipo.Modo.NUMEROS_ENTEROS));
        Label_Advertencia.setVisible(false);
        Panel_Advertencia.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        JPanel2 = new javax.swing.JPanel();
        Label_Reloj = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ComboBox_Cajero = new javax.swing.JComboBox<>();
        TxFd_ID_Producto = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla_Vender = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        TxFd_Precio_Unitario = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        TxFd_Total_Carrito = new javax.swing.JTextField();
        TxFd_Producto_Existencias = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        Btn_Agregar = new javax.swing.JButton();
        Btn_Eliminar = new javax.swing.JButton();
        Btn_Pagar = new javax.swing.JButton();
        Btn_Actualizar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        TxFd_Cantidad_Tomar = new javax.swing.JTextField();
        Panel_Advertencia = new javax.swing.JPanel();
        Label_Advertencia = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(2, 104, 115));
        jPanel3.setMaximumSize(new java.awt.Dimension(100, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(100, 500));
        jPanel3.setName(""); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 750));

        JPanel2.setBackground(new java.awt.Color(4, 191, 138));
        JPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Label_Reloj.setBackground(new java.awt.Color(255, 255, 255));
        Label_Reloj.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        JPanel2.add(Label_Reloj, new org.netbeans.lib.awtextra.AbsoluteConstraints(415, 33, 310, 40));

        getContentPane().add(JPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 750, 100));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Producto:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, -1));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Cajero:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        ComboBox_Cajero.setBackground(new java.awt.Color(255, 255, 255));
        ComboBox_Cajero.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ComboBox_Cajero.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(ComboBox_Cajero, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 40, 160, 30));

        TxFd_ID_Producto.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_ID_Producto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_ID_Producto.setForeground(new java.awt.Color(0, 0, 0));
        TxFd_ID_Producto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TxFd_ID_ProductoKeyReleased(evt);
            }
        });
        jPanel1.add(TxFd_ID_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 110, 30));

        Tabla_Vender.setBackground(new java.awt.Color(255, 255, 255));
        Tabla_Vender.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Tabla_Vender.setForeground(new java.awt.Color(0, 0, 0));
        Tabla_Vender.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Existencias", "Producto", "Precio Unit", "Cant Tomada", "Total Producto"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Tabla_Vender.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Tabla_VenderMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Tabla_Vender);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 690, 310));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Precio Unit:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 140, -1));

        TxFd_Precio_Unitario.setEditable(false);
        TxFd_Precio_Unitario.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Precio_Unitario.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Precio_Unitario.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(TxFd_Precio_Unitario, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 110, 30));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Total Carrito:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, -1, -1));

        TxFd_Total_Carrito.setEditable(false);
        TxFd_Total_Carrito.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Total_Carrito.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Total_Carrito.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(TxFd_Total_Carrito, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 240, 110, 30));

        TxFd_Producto_Existencias.setEditable(false);
        TxFd_Producto_Existencias.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Producto_Existencias.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Producto_Existencias.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(TxFd_Producto_Existencias, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 90, 100, 30));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Existencias:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 40, -1, -1));

        Btn_Agregar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Agregar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Agregar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Agregar.setText("Agregar");
        Btn_Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_AgregarActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 30, 200, 50));

        Btn_Eliminar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Eliminar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Eliminar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Eliminar.setText("Eliminar");
        Btn_Eliminar.setToolTipText("Para eliminar un articulo favor de hacer click en el articulo a eliminar de la tabla de abajo");
        Btn_Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_EliminarActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Eliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 170, 200, 50));

        Btn_Pagar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Pagar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Pagar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Pagar.setText("Pagar");
        Btn_Pagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_PagarActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Pagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 240, 200, 50));

        Btn_Actualizar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Actualizar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Actualizar.setText("Actualizar");
        Btn_Actualizar.setToolTipText("Para cambiar la cantidad de productos de un solo producto, favor de hacer click en el objeto en cuestion a editar");
        Btn_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, 200, 50));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Cant Tomar:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        TxFd_Cantidad_Tomar.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Cantidad_Tomar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Cantidad_Tomar.setForeground(new java.awt.Color(0, 0, 0));
        TxFd_Cantidad_Tomar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TxFd_Cantidad_TomarKeyReleased(evt);
            }
        });
        jPanel1.add(TxFd_Cantidad_Tomar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, 110, 30));

        Panel_Advertencia.setBackground(new java.awt.Color(255, 0, 51));

        javax.swing.GroupLayout Panel_AdvertenciaLayout = new javax.swing.GroupLayout(Panel_Advertencia);
        Panel_Advertencia.setLayout(Panel_AdvertenciaLayout);
        Panel_AdvertenciaLayout.setHorizontalGroup(
            Panel_AdvertenciaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        Panel_AdvertenciaLayout.setVerticalGroup(
            Panel_AdvertenciaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        jPanel1.add(Panel_Advertencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 120, 10, 10));

        Label_Advertencia.setBackground(new java.awt.Color(255, 255, 255));
        Label_Advertencia.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Label_Advertencia.setForeground(new java.awt.Color(153, 153, 153));
        Label_Advertencia.setText("Producto inhabilitado");
        Label_Advertencia.setToolTipText("Un articulo con esta advertencia no le permitira agregar el producto a su carrito");
        jPanel1.add(Label_Advertencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 120, -1, 20));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 750, 650));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TxFd_ID_ProductoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxFd_ID_ProductoKeyReleased
        if (TxFd_ID_Producto.getText().isBlank()) {
            TxFd_Precio_Unitario.setText("");
            TxFd_Cantidad_Tomar.setText("");
            TxFd_Producto_Existencias.setText("");
            return;
        }
        try {
            int ID_Producto = Integer.parseInt(TxFd_ID_Producto.getText());
            Producto Producto = Buscar_Producto(ID_Producto);
            if (Producto != null) {
                Label_Advertencia.setVisible(false);
                Panel_Advertencia.setVisible(false);

                if (!Producto.getEstado()) {
                    Label_Advertencia.setVisible(true);
                    Panel_Advertencia.setVisible(true);
                    return;
                }
                TxFd_Precio_Unitario.setText(String.valueOf(Producto.getPrecio()));
                TxFd_Producto_Existencias.setText(String.valueOf(Producto.getCantidad()));
                Btn_Agregar.setVisible(true);
            } else {
                TxFd_Precio_Unitario.setText("");
                TxFd_Producto_Existencias.setText("");
                Btn_Agregar.setVisible(false);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en keylistener.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_TxFd_ID_ProductoKeyReleased

    private void TxFd_Cantidad_TomarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxFd_Cantidad_TomarKeyReleased
        if (TxFd_Cantidad_Tomar.getText().isBlank()) {
            return;
        }
        try {
            int ID_Producto = Integer.parseInt(TxFd_ID_Producto.getText());
            int Cantidad_Tomar = Integer.parseInt(TxFd_Cantidad_Tomar.getText());
            Producto Producto = Buscar_Producto(ID_Producto);
            int Exedente = Cantidad_Tomar - Producto.getCantidad();

            if (Producto != null) {
                if (Cantidad_Tomar > Producto.getCantidad()) {
                    Exedente = Cantidad_Tomar - Producto.getCantidad();
                    JOptionPane.showMessageDialog(this, "No puede tomar mas producto del que hay, excede por : " + Exedente + " unidades.", "Error", JOptionPane.ERROR_MESSAGE);
                    TxFd_Cantidad_Tomar.setText("");
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_TxFd_Cantidad_TomarKeyReleased

    private void Tabla_VenderMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tabla_VenderMouseClicked
        try {
            int Producto_Seleccionado = Tabla_Vender.getSelectedRow();
            if (Producto_Seleccionado >= 0) {
                TxFd_ID_Producto.setText(String.valueOf(Modelo.getValueAt(Producto_Seleccionado, 0)));
                TxFd_Producto_Existencias.setText(String.valueOf(Modelo.getValueAt(Producto_Seleccionado, 1)));
                TxFd_Precio_Unitario.setText(String.valueOf(Modelo.getValueAt(Producto_Seleccionado, 3)));
                TxFd_Cantidad_Tomar.setText(String.valueOf(Modelo.getValueAt(Producto_Seleccionado, 4)));
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_Tabla_VenderMouseClicked

    private void Btn_AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AgregarActionPerformed
        try {
            if (TxFd_ID_Producto.getText().isBlank() || TxFd_Cantidad_Tomar.getText().isBlank()) {
                JOptionPane.showMessageDialog(this, "Ingrese producto y cantidad", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int ID_Producto = Integer.parseInt(TxFd_ID_Producto.getText());
            int Cantidad_Tomar = Integer.parseInt(TxFd_Cantidad_Tomar.getText());
            Producto Producto = Buscar_Producto(ID_Producto);

            if (Producto == null) {
                JOptionPane.showMessageDialog(this, "Producto no existe", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!Producto.getEstado()) {
                JOptionPane.showMessageDialog(this, "Producto inhabilitado", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int Cantidad_En_Carrito = 0;
            for (int i = 0; i < Modelo.getRowCount(); i++) {
                int ID_Carrito = (int) Modelo.getValueAt(i, 0);
                int Cantidad_Carrito = (int) Modelo.getValueAt(i, 4);

                if (ID_Carrito == Producto.getID_Producto()) {
                    Cantidad_En_Carrito += Cantidad_Carrito;
                }
            }

            if (Cantidad_Tomar + Cantidad_En_Carrito > Producto.getCantidad()) {
                int Max_Posible = Producto.getCantidad() - Cantidad_En_Carrito;
                JOptionPane.showMessageDialog(this, "No puede tomar más de lo disponible. Máximo permitido: " + Max_Posible, "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double Total_Producto = Cantidad_Tomar * Producto.getPrecio();

            Modelo.addRow(new Object[]{
                Producto.getID_Producto(),
                Producto.getCantidad(),
                Producto.getNombre(),
                Producto.getPrecio(),
                Cantidad_Tomar,
                Total_Producto
            });

            Actualizar_Vender_Total_Carrito(Modelo, TxFd_Total_Carrito);

            TxFd_ID_Producto.setText("");
            TxFd_Precio_Unitario.setText("");
            TxFd_Producto_Existencias.setText("");
            TxFd_Cantidad_Tomar.setText("");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Datos invalidos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_AgregarActionPerformed

    private void Btn_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ActualizarActionPerformed
        int Producto_Seleccionado = Tabla_Vender.getSelectedRow();
        if (Producto_Seleccionado < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto del carrito primero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int Nueva_Cantidad = Integer.parseInt(TxFd_Cantidad_Tomar.getText());
            int Cantidad_Existente = Integer.parseInt(TxFd_Producto_Existencias.getText());

            if (Nueva_Cantidad > Cantidad_Existente) {
                JOptionPane.showMessageDialog(this, "La cantidad supera las existencias disponibles.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (Nueva_Cantidad < 1) {
                JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida mayor a cero.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double Precio_Unitario = Double.parseDouble(TxFd_Precio_Unitario.getText());

            Tabla_Vender.setValueAt(Nueva_Cantidad, Producto_Seleccionado, 4);
            Tabla_Vender.setValueAt(Nueva_Cantidad * Precio_Unitario, Producto_Seleccionado, 5);

            Actualizar_Vender_Total_Carrito(Modelo, TxFd_Total_Carrito);

            TxFd_ID_Producto.setText("");
            TxFd_Precio_Unitario.setText("");
            TxFd_Cantidad_Tomar.setText("");
            TxFd_Producto_Existencias.setText("");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_ActualizarActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        Menu_Principal.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void Btn_EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EliminarActionPerformed
        int Producto_Seleccionado = Tabla_Vender.getSelectedRow();

        if (Producto_Seleccionado < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto del carrito primero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int Confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Está seguro que desea eliminar este producto del carrito?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (Confirmacion == JOptionPane.YES_OPTION) {
            Modelo.removeRow(Producto_Seleccionado);
            Actualizar_Vender_Total_Carrito(Modelo, TxFd_Total_Carrito);
        }
    }//GEN-LAST:event_Btn_EliminarActionPerformed

    private void Btn_PagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PagarActionPerformed
        try {
            if (Modelo.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No hay productos en el carrito.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int Confirmacion = JOptionPane.showConfirmDialog(this,
                    "¿Desea confirmar el pago de esta venta?",
                    "Confirmar pago", JOptionPane.YES_NO_OPTION);
            if (Confirmacion == JOptionPane.YES_OPTION) {
                int Cajero_Seleccionado = ComboBox_Cajero.getSelectedIndex();
                if (Cajero_Seleccionado <= 0) {
                    JOptionPane.showMessageDialog(this, "Seleccione un cajero.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                Cajero cajero = Clases_Utilidades.Lista_Cajeros.get(Cajero_Seleccionado - 1);
                Clases_Utilidades.Venta Venta_Actual = new Clases_Utilidades.Venta(cajero);

                for (int i = 0; i < Modelo.getRowCount(); i++) {
                    int ID_Producto = (int) Modelo.getValueAt(i, 0);
                    int Cantidad_Vendida = (int) Modelo.getValueAt(i, 4);
                    Producto Producto = Clases_Utilidades.Producto.Buscar_Producto(ID_Producto);

                    if (Producto != null) {
                        Producto.setCantidad(Producto.getCantidad() - Cantidad_Vendida);

                        Producto Producto_Vendido = new Producto(
                                Producto.getID_Producto(),
                                Producto.getNombre(),
                                Producto.getPrecio(),
                                Cantidad_Vendida,
                                Producto.getCategoria()
                        );

                        Venta_Actual.Productos_Vendidos.add(Producto_Vendido);
                        Venta_Actual.Total_Dinero += Cantidad_Vendida * Producto.getPrecio();
                    }
                }

                // Guardar la venta en tu lista de ventas
                Clases_Utilidades.Lista_Ventas.add(Venta_Actual);

                // Limpiar carrito
                Modelo.setRowCount(0);
                TxFd_Total_Carrito.setText("0");

                JOptionPane.showMessageDialog(this, "Venta realizada correctamente.\nTotal: $" + Venta_Actual.Total_Dinero);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al procesar la venta: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_PagarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_Actualizar;
    private javax.swing.JButton Btn_Agregar;
    private javax.swing.JButton Btn_Eliminar;
    private javax.swing.JButton Btn_Pagar;
    private javax.swing.JComboBox<String> ComboBox_Cajero;
    private javax.swing.JPanel JPanel2;
    private javax.swing.JLabel Label_Advertencia;
    private javax.swing.JLabel Label_Reloj;
    private javax.swing.JPanel Panel_Advertencia;
    private javax.swing.JTable Tabla_Vender;
    private javax.swing.JTextField TxFd_Cantidad_Tomar;
    private javax.swing.JTextField TxFd_ID_Producto;
    private javax.swing.JTextField TxFd_Precio_Unitario;
    private javax.swing.JTextField TxFd_Producto_Existencias;
    private javax.swing.JTextField TxFd_Total_Carrito;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
