package Interfaces_Graficas;

import Logica.Clases_Utilidades;
import static Logica.Clases_Utilidades.Actualizar_Categorias_Tabla;
import Logica.Clases_Utilidades.Categoria;
import static Logica.Clases_Utilidades.Categoria.Buscar_Categoria;
import static Logica.Clases_Utilidades.Lista_Categorias;
import javax.swing.JOptionPane;
import javax.swing.text.AbstractDocument;

public class Categorias extends javax.swing.JFrame {

    private Menu_Principal Menu_Principal;

    public void setMenu_Principal(Menu_Principal Menu_Principal) {
        this.Menu_Principal = Menu_Principal;
    }

    public Categorias() {
        initComponents();
        this.setLocationRelativeTo(null);
        Actualizar_Categorias_Tabla(Tabla_Categorias);
        ((AbstractDocument) TxFd_ID_Categoria.getDocument()).setDocumentFilter(new Clases_Utilidades.Limitador_Caracteres_Y_Tipo(5, Clases_Utilidades.Limitador_Caracteres_Y_Tipo.Modo.NUMEROS_ENTEROS));
        ((AbstractDocument) TxFd_Nombre.getDocument()).setDocumentFilter(new Clases_Utilidades.Limitador_Caracteres_Y_Tipo(30, Clases_Utilidades.Limitador_Caracteres_Y_Tipo.Modo.LETRAS));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        JPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TxFd_Nombre = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        TxFd_ID_Categoria = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla_Categorias = new javax.swing.JTable();
        Btn_Agregar = new javax.swing.JButton();
        Btn_Actualizar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        ComboBox_Estado = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Categorias");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(2, 104, 115));
        jPanel3.setMaximumSize(new java.awt.Dimension(100, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(100, 500));
        jPanel3.setName(""); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 750));

        JPanel2.setBackground(new java.awt.Color(4, 191, 138));

        javax.swing.GroupLayout JPanel2Layout = new javax.swing.GroupLayout(JPanel2);
        JPanel2.setLayout(JPanel2Layout);
        JPanel2Layout.setHorizontalGroup(
            JPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );
        JPanel2Layout.setVerticalGroup(
            JPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        getContentPane().add(JPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 750, 100));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("ID Categoria:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, -1));

        TxFd_Nombre.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Nombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Nombre.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(TxFd_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 200, 30));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Nombre:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        TxFd_ID_Categoria.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_ID_Categoria.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_ID_Categoria.setForeground(new java.awt.Color(0, 0, 0));
        TxFd_ID_Categoria.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TxFd_ID_CategoriaKeyReleased(evt);
            }
        });
        jPanel1.add(TxFd_ID_Categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, 110, 30));

        Tabla_Categorias.setBackground(new java.awt.Color(255, 255, 255));
        Tabla_Categorias.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Tabla_Categorias.setForeground(new java.awt.Color(0, 0, 0));
        Tabla_Categorias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla_Categorias);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 690, 310));

        Btn_Agregar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Agregar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Agregar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Agregar.setText("Agregar");
        Btn_Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_AgregarActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 120, 200, 50));

        Btn_Actualizar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Actualizar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Actualizar.setText("Actualizar");
        Btn_Actualizar.setToolTipText("Al dar desabilitar una categoria completa. se desabilitan todos los productos que tengan esa misma categoria, al volverl a activarla, se recuperan los estados anteriores de los productos");
        Btn_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 180, 200, 50));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Estado:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        ComboBox_Estado.setBackground(new java.awt.Color(255, 255, 255));
        ComboBox_Estado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ComboBox_Estado.setForeground(new java.awt.Color(0, 0, 0));
        ComboBox_Estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));
        jPanel1.add(ComboBox_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 210, 100, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 750, 650));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AgregarActionPerformed
        try {
            if (TxFd_ID_Categoria.getText().isBlank() || TxFd_Nombre.getText().isBlank()) {
                JOptionPane.showMessageDialog(this, "Llene todos los campos de texto.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int ID_Categoria = Integer.parseInt(TxFd_ID_Categoria.getText());
            String Nombre = TxFd_Nombre.getText();

            Categoria Categoria = new Categoria(ID_Categoria, Nombre);
            Lista_Categorias.add(Categoria);
            Actualizar_Categorias_Tabla(Tabla_Categorias);

            Btn_Agregar.setVisible(false);
            Btn_Actualizar.setVisible(true);

            JOptionPane.showMessageDialog(this, "Se agrego correctamente la categoria.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en agregar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_AgregarActionPerformed

    private void TxFd_ID_CategoriaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxFd_ID_CategoriaKeyReleased
        if (TxFd_ID_Categoria.getText().isBlank()) {
            TxFd_Nombre.setText(" ");
            return;
        }
        try {
            int ID_Categoria = Integer.parseInt(TxFd_ID_Categoria.getText());
            Categoria Categoria = Buscar_Categoria(ID_Categoria);
            if (Categoria != null) {
                TxFd_Nombre.setText(Categoria.getNombre());
                if (Categoria.getEstado()) {
                    ComboBox_Estado.setSelectedIndex(0);
                } else {
                    ComboBox_Estado.setSelectedIndex(1);
                }
                Btn_Agregar.setVisible(false);
                Btn_Actualizar.setVisible(true);
            } else {
                TxFd_Nombre.setText("");
                Btn_Agregar.setVisible(true);
                Btn_Actualizar.setVisible(false);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en keylistener.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_TxFd_ID_CategoriaKeyReleased

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        Menu_Principal.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    private void Btn_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ActualizarActionPerformed
        try {
            int ID_Categoria = Integer.parseInt(TxFd_ID_Categoria.getText());
            Categoria Categoria = Buscar_Categoria(ID_Categoria);

            if (ComboBox_Estado.getSelectedIndex() == 0) {
                if (Categoria.getEstado() == true) {
                    JOptionPane.showMessageDialog(this, "La categoria ya esta habilitada.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                int Confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea habilitar esta categoria? ", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (Confirmacion == JOptionPane.YES_OPTION) {
                    Categoria.setNombre(TxFd_Nombre.getText());
                    Categoria.setEstado(true);
                    Actualizar_Categorias_Tabla(Tabla_Categorias);
                    JOptionPane.showMessageDialog(this, "Se edito correctamente la categoria.");
                }
            } else {
                if (Categoria.getEstado() == false) {
                    JOptionPane.showMessageDialog(this, "La categoria ya esta desabilitada.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                int Confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea desabilitar esta categoria? ", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (Confirmacion == JOptionPane.YES_OPTION) {
                    Categoria.setNombre(TxFd_Nombre.getText());
                    Categoria.setEstado(false);
                    Actualizar_Categorias_Tabla(Tabla_Categorias);
                    JOptionPane.showMessageDialog(this, "Se edito correctamente la categoria.");
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en editar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_ActualizarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_Actualizar;
    private javax.swing.JButton Btn_Agregar;
    private javax.swing.JComboBox<String> ComboBox_Estado;
    private javax.swing.JPanel JPanel2;
    private javax.swing.JTable Tabla_Categorias;
    private javax.swing.JTextField TxFd_ID_Categoria;
    private javax.swing.JTextField TxFd_Nombre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
