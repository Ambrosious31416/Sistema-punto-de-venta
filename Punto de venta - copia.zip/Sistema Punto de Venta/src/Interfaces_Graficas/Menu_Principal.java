/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfaces_Graficas;

public class Menu_Principal extends javax.swing.JFrame {

    public Menu_Principal() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Panel_Principal_Intercambiable = new javax.swing.JPanel();
        Btn_Productos = new javax.swing.JButton();
        Btn_Cajeros = new javax.swing.JButton();
        Btn_Vender = new javax.swing.JButton();
        Btn_Historial_Ventas = new javax.swing.JButton();
        Btn_Categorias = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        JPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu Principal");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Panel_Principal_Intercambiable.setBackground(new java.awt.Color(255, 255, 255));
        Panel_Principal_Intercambiable.setForeground(new java.awt.Color(0, 0, 0));
        Panel_Principal_Intercambiable.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Btn_Productos.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Productos.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Btn_Productos.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Productos.setText("Productos");
        Btn_Productos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ProductosActionPerformed(evt);
            }
        });
        Panel_Principal_Intercambiable.add(Btn_Productos, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 110, 160, 70));

        Btn_Cajeros.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Cajeros.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Btn_Cajeros.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Cajeros.setText("Cajeros");
        Btn_Cajeros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_CajerosActionPerformed(evt);
            }
        });
        Panel_Principal_Intercambiable.add(Btn_Cajeros, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, 160, 70));

        Btn_Vender.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Vender.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Btn_Vender.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Vender.setText("Vender");
        Btn_Vender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_VenderActionPerformed(evt);
            }
        });
        Panel_Principal_Intercambiable.add(Btn_Vender, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 270, 160, 70));

        Btn_Historial_Ventas.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Historial_Ventas.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Btn_Historial_Ventas.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Historial_Ventas.setText("Historial de Ventas");
        Btn_Historial_Ventas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_Historial_VentasActionPerformed(evt);
            }
        });
        Panel_Principal_Intercambiable.add(Btn_Historial_Ventas, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 430, 250, 80));

        Btn_Categorias.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Categorias.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        Btn_Categorias.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Categorias.setText("Categorias");
        Btn_Categorias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_CategoriasActionPerformed(evt);
            }
        });
        Panel_Principal_Intercambiable.add(Btn_Categorias, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 160, 70));

        getContentPane().add(Panel_Principal_Intercambiable, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 750, 650));

        jPanel3.setBackground(new java.awt.Color(2, 104, 115));
        jPanel3.setMaximumSize(new java.awt.Dimension(100, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(100, 500));
        jPanel3.setName(""); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 750));

        JPanel2.setBackground(new java.awt.Color(4, 191, 138));

        javax.swing.GroupLayout JPanel2Layout = new javax.swing.GroupLayout(JPanel2);
        JPanel2.setLayout(JPanel2Layout);
        JPanel2Layout.setHorizontalGroup(
            JPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );
        JPanel2Layout.setVerticalGroup(
            JPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        getContentPane().add(JPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 750, 100));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Btn_ProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ProductosActionPerformed
        Productos Menu_Productos = new Productos();
        Menu_Productos.setMenu_Principal(this);
        Menu_Productos.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Btn_ProductosActionPerformed

    private void Btn_CajerosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CajerosActionPerformed
        Cajeros Menu_Cajeros = new Cajeros();
        Menu_Cajeros.setMenu_Principal(this);
        Menu_Cajeros.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Btn_CajerosActionPerformed

    private void Btn_VenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_VenderActionPerformed
        Vender Menu_Vender = new Vender();
        Menu_Vender.setMenu_Principal(this);
        Menu_Vender.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Btn_VenderActionPerformed

    private void Btn_Historial_VentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_Historial_VentasActionPerformed
        Historial_Ventas Menu_Historial_Ventas = new Historial_Ventas();
        Menu_Historial_Ventas.setMenu_Principal(this);
        Menu_Historial_Ventas.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Btn_Historial_VentasActionPerformed

    private void Btn_CategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CategoriasActionPerformed
        Categorias Menu_Categorias = new Categorias();
        Menu_Categorias.setMenu_Principal(this);
        Menu_Categorias.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Btn_CategoriasActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu_Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_Cajeros;
    private javax.swing.JButton Btn_Categorias;
    private javax.swing.JButton Btn_Historial_Ventas;
    private javax.swing.JButton Btn_Productos;
    private javax.swing.JButton Btn_Vender;
    private javax.swing.JPanel JPanel2;
    private javax.swing.JPanel Panel_Principal_Intercambiable;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
