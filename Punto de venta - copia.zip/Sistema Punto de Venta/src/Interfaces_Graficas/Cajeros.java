/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Interfaces_Graficas;

import Logica.Clases_Utilidades;
import static Logica.Clases_Utilidades.Actualizar_Cajeros_Tabla;
import Logica.Clases_Utilidades.Cajero;
import static Logica.Clases_Utilidades.Cajero.Buscar_Cajero;
import static Logica.Clases_Utilidades.Lista_Cajeros;
import javax.swing.JOptionPane;
import javax.swing.text.AbstractDocument;

public class Cajeros extends javax.swing.JFrame {

    private Menu_Principal Menu_Principal;

    public void setMenu_Principal(Menu_Principal Menu_Principal) {
        this.Menu_Principal = Menu_Principal;
    }

    public Cajeros() {
        initComponents();
        this.setLocationRelativeTo(null);
        ((AbstractDocument) TxFd_ID_Cajero.getDocument()).setDocumentFilter(new Clases_Utilidades.Limitador_Caracteres_Y_Tipo(5, Clases_Utilidades.Limitador_Caracteres_Y_Tipo.Modo.NUMEROS_ENTEROS));
        ((AbstractDocument) TxFd_Nombres.getDocument()).setDocumentFilter(new Clases_Utilidades.Limitador_Caracteres_Y_Tipo(38, Clases_Utilidades.Limitador_Caracteres_Y_Tipo.Modo.LETRAS));
        ((AbstractDocument) TxFd_Apellidos.getDocument()).setDocumentFilter(new Clases_Utilidades.Limitador_Caracteres_Y_Tipo(38, Clases_Utilidades.Limitador_Caracteres_Y_Tipo.Modo.LETRAS));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        JPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        TxFd_ID_Cajero = new javax.swing.JTextField();
        TxFd_Nombres = new javax.swing.JTextField();
        TxFd_Apellidos = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla_Cajeros = new javax.swing.JTable();
        Btn_Agregar = new javax.swing.JButton();
        Btn_Actualizar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        ComboBox_Estado = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(2, 104, 115));
        jPanel3.setMaximumSize(new java.awt.Dimension(100, 500));
        jPanel3.setMinimumSize(new java.awt.Dimension(100, 500));
        jPanel3.setName(""); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 750));

        JPanel2.setBackground(new java.awt.Color(4, 191, 138));

        javax.swing.GroupLayout JPanel2Layout = new javax.swing.GroupLayout(JPanel2);
        JPanel2.setLayout(JPanel2Layout);
        JPanel2Layout.setHorizontalGroup(
            JPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );
        JPanel2Layout.setVerticalGroup(
            JPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        getContentPane().add(JPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, 750, 100));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Estado:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("ID Cajero:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Nombre/s:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));

        TxFd_ID_Cajero.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_ID_Cajero.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_ID_Cajero.setForeground(new java.awt.Color(0, 0, 0));
        TxFd_ID_Cajero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TxFd_ID_CajeroKeyReleased(evt);
            }
        });
        jPanel1.add(TxFd_ID_Cajero, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 110, 30));

        TxFd_Nombres.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Nombres.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Nombres.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(TxFd_Nombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, 200, 30));

        TxFd_Apellidos.setBackground(new java.awt.Color(255, 255, 255));
        TxFd_Apellidos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        TxFd_Apellidos.setForeground(new java.awt.Color(0, 0, 0));
        jPanel1.add(TxFd_Apellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 200, 30));

        Tabla_Cajeros.setBackground(new java.awt.Color(255, 255, 255));
        Tabla_Cajeros.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Tabla_Cajeros.setForeground(new java.awt.Color(0, 0, 0));
        Tabla_Cajeros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre/s ", "Apellido/s", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla_Cajeros);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 690, 310));

        Btn_Agregar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Agregar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Agregar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Agregar.setText("Agregar");
        Btn_Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_AgregarActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, 200, 50));

        Btn_Actualizar.setBackground(new java.awt.Color(2, 89, 64));
        Btn_Actualizar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Btn_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        Btn_Actualizar.setText("Actualizar");
        Btn_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Btn_ActualizarActionPerformed(evt);
            }
        });
        jPanel1.add(Btn_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 170, 200, 50));

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Apellido/s:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        ComboBox_Estado.setBackground(new java.awt.Color(255, 255, 255));
        ComboBox_Estado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ComboBox_Estado.setForeground(new java.awt.Color(0, 0, 0));
        ComboBox_Estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));
        jPanel1.add(ComboBox_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 220, 100, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, 750, 650));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TxFd_ID_CajeroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxFd_ID_CajeroKeyReleased
        if (TxFd_ID_Cajero.getText().isBlank()) {
            TxFd_Nombres.setText(" ");
            return;
        }
        try {
            int ID_Cajero = Integer.parseInt(TxFd_ID_Cajero.getText());
            Cajero Cajero = Buscar_Cajero(ID_Cajero);
            if (Cajero != null) {
                TxFd_Nombres.setText(Cajero.getNombres());
                TxFd_Apellidos.setText(Cajero.getApellidos());
                if (Cajero.getEstado()) {
                    ComboBox_Estado.setSelectedIndex(0);
                } else {
                    ComboBox_Estado.setSelectedIndex(1);
                }
                Btn_Agregar.setVisible(false);
                Btn_Actualizar.setVisible(true);
            } else {
                TxFd_Nombres.setText("");
                TxFd_Apellidos.setText("");
                Btn_Agregar.setVisible(true);
                Btn_Actualizar.setVisible(false);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en keylistener.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_TxFd_ID_CajeroKeyReleased

    private void Btn_AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AgregarActionPerformed
        try {
            if (TxFd_ID_Cajero.getText().isBlank() || TxFd_Nombres.getText().isBlank() || TxFd_Apellidos.getText().isBlank()) {
                JOptionPane.showMessageDialog(this, "Llene todos los campos de texto.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int ID_Cajero = Integer.parseInt(TxFd_ID_Cajero.getText());
            String Nombres = TxFd_Nombres.getText();
            String Apellidos = TxFd_Apellidos.getText();

            Cajero Caja = new Cajero(ID_Cajero, Nombres, Apellidos);
            Lista_Cajeros.add(Caja);
            Actualizar_Cajeros_Tabla(Tabla_Cajeros);

            Btn_Agregar.setVisible(false);
            Btn_Actualizar.setVisible(true);

            JOptionPane.showMessageDialog(this, "Se agrego correctamente el cajero.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en agregar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_AgregarActionPerformed

    private void Btn_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ActualizarActionPerformed
        try {
            int ID_Cajero = Integer.parseInt(TxFd_ID_Cajero.getText());
            Cajero Cajero = Buscar_Cajero(ID_Cajero);

            if (ComboBox_Estado.getSelectedIndex() == 0) {
                if (Cajero.getEstado() == true) {
                    JOptionPane.showMessageDialog(this, "El cajero ya esta habilitado.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                int Confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea habilitar este cajero? ", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (Confirmacion == JOptionPane.YES_OPTION) {
                    Cajero.setNombres(TxFd_Nombres.getText());
                    Cajero.setEstado(true);
                    Actualizar_Cajeros_Tabla(Tabla_Cajeros);
                    JOptionPane.showMessageDialog(this, "Se edito correctamente el cajero.");
                }
            } else {
                if (Cajero.getEstado() == false) {
                    JOptionPane.showMessageDialog(this, "El cajero ya esta desabilitado.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                int Confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea desabilitar este cajero? ", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (Confirmacion == JOptionPane.YES_OPTION) {
                    Cajero.setNombres(TxFd_Nombres.getText());
                    Cajero.setEstado(false);
                    Actualizar_Cajeros_Tabla(Tabla_Cajeros);
                    JOptionPane.showMessageDialog(this, "Se edito correctamente el cajero.");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error en editar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Btn_ActualizarActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        Menu_Principal.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_formWindowClosing

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Btn_Actualizar;
    private javax.swing.JButton Btn_Agregar;
    private javax.swing.JComboBox<String> ComboBox_Estado;
    private javax.swing.JPanel JPanel2;
    private javax.swing.JTable Tabla_Cajeros;
    private javax.swing.JTextField TxFd_Apellidos;
    private javax.swing.JTextField TxFd_ID_Cajero;
    private javax.swing.JTextField TxFd_Nombres;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
